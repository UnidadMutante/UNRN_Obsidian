#include <stdio.h>

int fibRec(int n)
{
	if ((n==0) || (n==1))
    {
        return 1;
    }	
    else 
    {
        return (fibRec(n-2)+fibRec(n-1));
    }
}

int factRec(int n)
{
    if (n==0) return 1;
    else return factRec(n-1)*n;
}


/*
1- 
[1,2,3,4,5,6,7,8,9]  2
n=9
d=0;
h=8;
(h+d)/2 = 8/2 = 4
p=5

2<5
binSearch(a,9, 0,3)


(8-5)/2 -> 1

medio = (h-d);
if (a[medio]==e)
{
    return medio;
}



*/
int binSearchRec2(int a[], int d, int h,int e)
{
    printf("[binSearchRec2] d:%d h:%d \n",d,h);
    int medio = (h+d)/2;
    if (d<h){

        
        int p = a[medio];
        if (p==e)    return medio;
        else
        {
            if (e<p)
            {
                return binSearchRec2(a, d,medio-1,e);
            } 
            else 
            {
                return binSearchRec2(a, medio+1,h,e);
            }
        }
    }
    else
    {
        return -1;
    }

}


int binSearchRec(int a[],int n, int e)
{
    return binSearchRec2(a,0,n-1,e);
}

int main(void)
{

    for(int i=0;i<20;i++)
    {
        printf("%d-esimo Fibonacci: %d  -  %d!:%d \n",i,fibRec(i),i,factRec(i));
    }


    /////////////////////
    int a[] = {1,2,3,4,5,6,7,8,9};
    int tam = sizeof(a)/sizeof(a[0]);
    printf("tam: %d\n",tam);

    int e[] = {0,10,2,5}; 
    for(int i=0;i<4;i++)
    {
        printf("%d esta en la posición %d de a[]\n",e[i],binSearchRec(a,tam,e[i]));
    }
    
}