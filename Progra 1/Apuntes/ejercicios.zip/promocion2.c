#include <stdio.h>
#include <stdbool.h>

typedef struct 
{
    char nombre[32];
    float precio;
} producto_t;


bool aplica_descuento(producto_t precios[], size_t nprecios, float cupon);

void testear_descuento(producto_t precios[], size_t tam, float cupon)
{
    if (aplica_descuento(precios,tam,cupon))
    {
        printf("¡¡se hace descuento en la lista!!\n");
    }
    else
    {
        printf("No aplica descuento a la lista... :( )\n");
    }
}

int main(void)
{

    float cupon = 100;

    producto_t canasta[] = {{"prod1",10},{"prod2",20},{"prod3",30},{"prod4",40},{"prod3",28},{"prod3",2},{"prod3",15}};
    size_t tam1 = sizeof(canasta)/sizeof(canasta[0]);
        
    printf("Testear descuento\n");

    printf("Caso 1\n");
    testear_descuento(canasta,tam1,50);

    printf("Caso 2\n");
    testear_descuento(canasta,tam1,90);
          
    return 0;
}


bool aplica_descuento(producto_t precios[], size_t tam, float cupon)
{
    bool aplica=false;

    for(size_t i=0;i<tam && aplica==false;i++)  //i=tam-1
    {
        for(size_t j=i+1;j<tam && aplica==false;j++) // j=tam-1+1 = tamp
        {
            if (precios[i].precio + precios[j].precio == cupon)
            {       
                aplica=true;
            }
        }
    }
    return aplica;
}
